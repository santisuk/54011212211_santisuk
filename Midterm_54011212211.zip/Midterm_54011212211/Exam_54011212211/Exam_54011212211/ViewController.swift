//
//  ViewController.swift
//  Exam_54011212211
//
//  Created by iStudents on 3/13/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
let tipcalc = Exam1(total: 33.25, taxPct: 0.06)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
//var soo = 0
    
    @IBOutlet weak var tex2: UITextField!
    
    @IBOutlet weak var tex4: UITextField!
    
    @IBOutlet weak var tex6: UITextField!
    
    @IBOutlet weak var Taxlabel: UILabel!
    
    @IBOutlet weak var Taxslider: UISlider!
    
    
    
    
    @IBAction func button1(sender: AnyObject) {
        
        
       
       
    
        // }
    
    }
    
    @IBAction func button2(sender: AnyObject) {
        
    }
    var name = ""
    var sum = ""
    var pp = ""
    var mid = 0.0
    var final = 0.0
    var geb = 0.0
    func  data() {
        
        mid = Double((tex2.text  as NSString ).doubleValue)
        
        final = Double((tex4.text  as NSString ).doubleValue)
        
        geb   = Double((tex6.text  as NSString ).doubleValue)
    
    }
    
    
    
    

    
    
   
   /* func calctipwithtipPct(pp:Double) ->String {
        
        if pp >= 80 {
            sum = "A"
        }
        else if  pp >= 70 {
            sum = "B"
        }
        else if  pp >= 60 {
            sum = "C"
        }
        else if  pp >= 50 {
            sum = "D"
        }
        else if  pp <= 40 {
            sum = "F"
        }
    
    
    }*/
    

    
            
        
            
    
    
    @IBAction func ResetAll(sender: AnyObject) {
        
        tex2.text = ""
        tex4.text = ""
        tex6.text = ""
        
    
    }
    
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

